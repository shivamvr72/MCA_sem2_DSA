#include <stdio.h>
#define s 10

void insertAtRear(int *queue, int *front, int *rear, int item)
{
    if (*rear == (s - 1))
    {
        printf("Queue is full !\n");
        return;
    }
    else if (*front == -1)
    {
        *front += 1;
    }

    queue[*rear + 1] = item;
    *rear += 1;
}

int deleteAtFront(int *queue, int *front, int *rear)
{
    if (*front == -1)
    {
        printf("Queue is empty !\n");
        return 0;
    }
    int i = queue[*front];
    if (*front == *rear)
    {
        *front = *rear = -1;
        return i;
    }
    *front += 1;
    return i;
}

void insertAtFront(int *queue, int *front, int item)
{
    if (*front <= 0)
    {
        printf("Underflow !\n");
        return;
    }

    queue[*front - 1] = item;
    *front -= 1;
}

int deleteAtRear(int *queue, int *front, int *rear)
{
    if (*rear - 1 < 0)
    {
        printf("Queue is empty !\n");
        return 0;
    }
    int i = queue[*rear];
    if (*front == *rear)
    {
        *front = *rear = -1;
        return i;
    }
    *rear -= 1;
    return i;
}

void display(int *queue, int *front, int *rear)
{
    int temp[s], f = -1, r = -1;
    while (*front != -1)
    {
        int t = deleteAtFront(queue, front, rear);
        if (t)
        {
            printf("%d| ", t);
            insertAtRear(temp, &f, &r, t);
        }
    }
    printf("\n");

    while (f != -1)
    {
        int t = deleteAtFront(temp, &f, &r);
        if (t)
            insertAtRear(queue, front, rear, t);
    }
}

int main()
{
    int ch, x, queue[s], front = -1, rear = -1;
    while (1)
    {
        printf("\n 1.insert at front\n 2.insert at rear\n 3. delete from front \n 4.delete from rear\n 5.display\n 6.exit\n");
        printf("enter your choice:");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1:
            printf("enter an element:");
            scanf("%d", &x);
            insertAtFront(queue, &front, x);
            break;
        case 2:
            printf("enter an element:");
            scanf("%d", &x);
            insertAtRear(queue, &front, &rear, x);
            break;
        case 3:
            deleteAtFront(queue, &front, &rear);
            break;
        case 4:
            deleteAtRear(queue, &front, &rear);
            break;

        case 5:
            display(queue, &front, &rear);
            break;

        case 6:
            return 0;
        }
    }
    return 0;
}
